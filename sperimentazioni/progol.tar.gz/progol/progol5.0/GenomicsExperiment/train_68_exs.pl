:- phenotypic_effect(gene_i,[nut_1,nut_2]).
:- phenotypic_effect(gene_c,[nut_1,nut_2]).
phenotypic_effect(gene_k,[nut_1,nut_2]).
:- phenotypic_effect(gene_b,[nut_1,nut_2,nut_3]).
:- phenotypic_effect(gene_h,[nut_3]).
:- phenotypic_effect(gene_j,[nut_3]).
phenotypic_effect(gene_l,[nut_2]).
:- phenotypic_effect(gene_f,[nut_2]).
phenotypic_effect(gene_d,[nut_1,nut_2]).
:- phenotypic_effect(gene_h,[nut_1,nut_2,nut_3]).
phenotypic_effect(gene_m,[nut_1,nut_3]).
:- phenotypic_effect(gene_e,[nut_2,nut_3]).
:- phenotypic_effect(gene_c,[nut_2,nut_3]).
:- phenotypic_effect(gene_j,[nut_2,nut_3]).
phenotypic_effect(gene_j,[nut_1]).
phenotypic_effect(gene_l,[nut_1,nut_2,nut_3]).
:- phenotypic_effect(gene_j,[nut_2]).
:- phenotypic_effect(gene_g,[nut_1,nut_2]).
phenotypic_effect(gene_m,[nut_2,nut_3]).
phenotypic_effect(gene_e,[nut_1,nut_3]).
phenotypic_effect(gene_l,[nut_1,nut_2]).
:- phenotypic_effect(gene_l,[nut_3]).
phenotypic_effect(gene_m,[nut_2]).
:- phenotypic_effect(gene_i,[nut_1]).
phenotypic_effect(gene_e,[nut_1,nut_2]).
phenotypic_effect(gene_b,[nut_2]).
phenotypic_effect(gene_k,[nut_1]).
phenotypic_effect(gene_l,[nut_2,nut_3]).
phenotypic_effect(gene_f,[nut_1,nut_3]).
phenotypic_effect(gene_j,[nut_1,nut_2,nut_3]).
phenotypic_effect(gene_c,[nut_3]).
phenotypic_effect(gene_j,[nut_1,nut_3]).
:- phenotypic_effect(gene_d,[nut_2,nut_3]).
:- phenotypic_effect(gene_i,[nut_2]).
phenotypic_effect(gene_h,[nut_2]).
phenotypic_effect(gene_m,[nut_1,nut_2,nut_3]).
:- phenotypic_effect(gene_c,[nut_2]).
phenotypic_effect(gene_e,[nut_1]).
:- phenotypic_effect(gene_f,[nut_2,nut_3]).
:- phenotypic_effect(gene_f,[nut_1,nut_2]).
:- phenotypic_effect(gene_b,[nut_3]).
:- phenotypic_effect(gene_i,[nut_2,nut_3]).
:- phenotypic_effect(gene_h,[nut_1,nut_3]).
:- phenotypic_effect(gene_g,[nut_1]).
phenotypic_effect(gene_d,[nut_1]).
:- phenotypic_effect(gene_g,[nut_1,nut_3]).
phenotypic_effect(gene_c,[nut_1,nut_3]).
phenotypic_effect(gene_b,[nut_2,nut_3]).
phenotypic_effect(gene_m,[nut_1]).
phenotypic_effect(gene_j,[nut_1,nut_2]).
phenotypic_effect(gene_k,[nut_1,nut_2,nut_3]).
:- phenotypic_effect(gene_e,[nut_2]).
:- phenotypic_effect(gene_h,[nut_2,nut_3]).
:- phenotypic_effect(gene_g,[nut_1,nut_2,nut_3]).
:- phenotypic_effect(gene_g,[nut_3]).
:- phenotypic_effect(gene_d,[nut_3]).
:- phenotypic_effect(gene_k,[nut_2,nut_3]).
:- phenotypic_effect(gene_m,[nut_3]).
:- phenotypic_effect(gene_a,[nut_2]).
:- phenotypic_effect(gene_i,[nut_1,nut_2,nut_3]).
:- phenotypic_effect(gene_e,[nut_3]).
phenotypic_effect(gene_e,[nut_1,nut_2,nut_3]).
phenotypic_effect(gene_a,[nut_1]).
:- phenotypic_effect(gene_a,[nut_3]).
:- phenotypic_effect(gene_a,[nut_2,nut_3]).
:- phenotypic_effect(gene_f,[nut_1,nut_2,nut_3]).
phenotypic_effect(gene_g,[nut_2,nut_3]).
:- phenotypic_effect(gene_c,[nut_1,nut_2,nut_3]).
