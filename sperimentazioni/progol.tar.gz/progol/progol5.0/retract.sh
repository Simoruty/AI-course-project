rm source/*.o source/progol source/qsample
tar cvf progol5_0.tar examples5_0 source
gzip progol5_0.tar
rm -r source examples5_0
