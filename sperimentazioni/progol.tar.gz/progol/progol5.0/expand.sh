gunzip progol5_0.tar.gz
tar xvf progol5_0.tar
cd source
make
make qsample
cd ..
